<?php
/**
 * Discounts Table.
 *
 * @package     RCP
 * @subpackage  Database\Tables
 * @copyright   Copyright (c) 2019, Easy Digital Downloads, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       3.3
 */

namespace RCP\Database\Tables;

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

use RCP\Database\Table;

/**
 * Setup the "rcp_discounts" database table
 *
 * @since 3.3
 */
final class Discounts extends Table {

	/**
	 * @var string Table name
	 */
	protected $name = 'discounts';

	/**
	 * @var string Database version
	 */
	protected $version = 202002101;

	/**
	 * @var array Array of upgrade versions and methods
	 */
	protected $upgrades = array(
		'201907101' => 201907101,
		'201907102' => 201907102,
		'201907103' => 201907103,
		'201907104' => 201907104,
		'202002101' => 202002101
	);

	/**
	 * Discounts constructor.
	 *
	 * @access public
	 * @since  3.3
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Setup the database schema
	 *
	 * @access protected
	 * @since  3.3
	 * @return void
	 */
	protected function set_schema() {
		$this->schema = "id bigint(9) NOT NULL AUTO_INCREMENT,
			name tinytext NOT NULL DEFAULT '',
			description longtext NOT NULL default '',
			amount tinytext NOT NULL,
			unit tinytext NOT NULL DEFAULT '',
			code tinytext NOT NULL DEFAULT '',
			use_count mediumint NOT NULL DEFAULT '0',
			max_uses mediumint NOT NULL DEFAULT '0',
			status tinytext NOT NULL,
			expiration datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			membership_level_ids text NOT NULL DEFAULT '',
			one_time smallint NOT NULL DEFAULT 0,
			date_created datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			date_modified datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			uuid varchar(100) NOT NULL DEFAULT '',
			PRIMARY KEY (id)";
	}

	/**
	 * If the old `rcp_discounts_db_version` option exists, copy that value to our new version key.
	 * This will ensure new upgrades are processed on old installs.
	 *
	 * @since 3.3
	 */
	public function maybe_upgrade() {

		if ( false !== get_option( 'rcp_discounts_db_version' ) ) {
			update_option( $this->db_version_key, get_option( 'rcp_discounts_db_version' ) );

			delete_option( 'rcp_discounts_db_version' );
		}

		return parent::maybe_upgrade();
	}

	/**
	 * Upgrade to 201907101
	 *      - Update `expiration` type to `datetime`.
	 *
	 * @since 3.3
	 * @return bool
	 */
	protected function __201907101() {

		$result = $this->get_db()->query( "ALTER TABLE {$this->table_name} MODIFY expiration datetime NOT NULL DEFAULT '0000-00-00 00:00:00'" );

		$success = $this->is_success( $result );

		if ( $success ) {
			rcp_log( sprintf( '%s table upgrade to 201907101 successful.', $this->get_table_name() ) );
		} else {
			rcp_log( sprintf( '%s table upgrade to 201907101 failure.', $this->get_table_name() ) );
		}

		return $success;

	}

	/**
	 * Upgrade to 201907102
	 *      - Add `date_created` column.
	 *
	 * @since 3.3
	 * @return bool
	 */
	protected function __201907102() {

		// Look for column
		$result = $this->column_exists( 'date_created' );

		// Add column if it doesn't exist.
		if ( false === $result ) {
			$result = $this->get_db()->query( "ALTER TABLE {$this->table_name} ADD COLUMN date_created datetime NOT NULL DEFAULT '0000-00-00 00:00:00';" );
		}

		$success = $this->is_success( $result );

		if ( $success ) {
			rcp_log( sprintf( '%s table upgrade to 201907102 successful.', $this->get_table_name() ) );
		} else {
			rcp_log( sprintf( '%s table upgrade to 201907102 failure.', $this->get_table_name() ) );
		}

		return $success;

	}

	/**
	 * Upgrade to 201907103
	 *      - Add `date_modified` column.
	 *
	 * @since 3.3
	 * @return bool
	 */
	protected function __201907103() {

		// Look for column
		$result = $this->column_exists( 'date_modified' );

		// Add column if it doesn't exist.
		if ( false === $result ) {
			$result = $this->get_db()->query( "ALTER TABLE {$this->table_name} ADD COLUMN date_modified datetime NOT NULL DEFAULT '0000-00-00 00:00:00';" );
		}

		$success = $this->is_success( $result );

		if ( $success ) {
			rcp_log( sprintf( '%s table upgrade to 201907103 successful.', $this->get_table_name() ) );
		} else {
			rcp_log( sprintf( '%s table upgrade to 201907103 failure.', $this->get_table_name() ) );
		}

		return $success;

	}

	/**
	 * Upgrade to 201907104
	 *      - Add `uuid` column.
	 *
	 * @since 3.3
	 * @return bool
	 */
	protected function __201907104() {

		// Look for column
		$result = $this->column_exists( 'uuid' );

		// Add column if it doesn't exist.
		if ( false === $result ) {
			$result = $this->get_db()->query( "ALTER TABLE {$this->table_name} ADD COLUMN uuid varchar(100) NOT NULL DEFAULT '';" );
		}

		$success = $this->is_success( $result );

		if ( $success ) {
			rcp_log( sprintf( '%s table upgrade to 201907104 successful.', $this->get_table_name() ) );
		} else {
			rcp_log( sprintf( '%s table upgrade to 201907104 failure.', $this->get_table_name() ) );
		}

		return $success;

	}

	/**
	 * Upgrade to 202002101
	 *      - Add `one_time` column if it doesn't already exist. This column was actually added in a previous
	 *        version of RCP, but there appear to be some issues with customers missing it.
	 *
	 * @link https://github.com/restrictcontentpro/restrict-content-pro/issues/2698
	 *
	 * @since 3.3.7
	 * @return bool
	 */
	protected function __202002101() {

		// Look for column
		$result = $this->column_exists( 'one_time' );

		// Add column if it doesn't exist.
		if ( false === $result ) {
			$result = $this->get_db()->query( "ALTER TABLE {$this->table_name} ADD COLUMN one_time smallint NOT NULL DEFAULT 0 AFTER membership_level_ids;" );

			global $rcp_options;

			if ( $this->is_success( $result ) && ! empty( $rcp_options['one_time_discounts'] ) ) {
				rcp_log( 'Setting all discounts to one time.', true );

				$this->get_db()->query( "UPDATE {$this->table_name} SET one_time = 1" );
			}
		}

		$success = $this->is_success( $result );

		if ( $success ) {
			rcp_log( sprintf( '%s table upgrade to 202002101 successful.', $this->get_table_name() ) );
		} else {
			rcp_log( sprintf( '%s table upgrade to 202002101 failure.', $this->get_table_name() ) );
		}

		return $success;

	}


}
