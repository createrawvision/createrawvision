module.exports = {
	main: ['build/<%= pkg.name %>']
};